<script src="js/script.js"></script>

</body>

</html>