var myMap = L.map('map').setView([-0.8931699926701577, 119.86473745747928], 14);

let layerMap = L.tileLayer(
	'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibmF1ZmFsaGFtYmFsaTY1IiwiYSI6ImNtMnd4eWdlZDBidjYyanBwaHJnZ3FrbHAifQ.mJdw4Ew-5zOyObCXR8akhg',
	{
		attribution:
			'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery <a href="https://www.mapbox.com/">Mapbox</a>',
		id: 'mapbox/streets-v12',
	}
);

myMap.addLayer(layerMap);

let dinkes = L.marker([-0.9016647207084186, 119.87567231523664])
	.bindPopup(
		'Nama : Dinas Kesehatan<br>Alamat :Jl. R.A. Kartini No.11, Lolu utara, Kec. Palu Sel., Kota Palu, Sulawesi Tengah'
	)
	.addTo(myMap);
let dinsos = L.marker([-0.9013186006040836, 119.88394265532263])
	.bindPopup(
		'Nama : Dinas Sosisial<br>Alamat : Jl. Prof. Moh. Yamin, Tanamodindi Mantikulore, Palu City, Central Sulawesi 94111'
	)
	.addTo(myMap);
let diskominfo = L.marker([-0.9054812934487328, 119.88989875747575])
	.bindPopup(
		'Nama : Dinas Kominfo<br>Alamat : Jl. R.A. kartini, Lolu Sel., kec Palu Tim., Kota Palu, Sulawesi Tengah'
	)
	.addTo(myMap);

let baseLayers = [
	{
		group: 'Tipe Maps',
		layers: [
			{
				name: 'light',
				layer: layerMap,
			},
			{
				name: 'street',
				layer: L.tileLayer(
					'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
					{
						attribution:
							'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
					}
				),
			},
			{
				name: 'dark',
				layer: L.tileLayer(
					'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibmF1ZmFsaGFtYmFsaTY1IiwiYSI6ImNtMnd4eWdlZDBidjYyanBwaHJnZ3FrbHAifQ.mJdw4Ew-5zOyObCXR8akhg',
					{
						attribution:
							'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
							'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
							'Imagery <a href="https://www.mapbox.com/">Mapbox</a>',
						id: 'mapbox/dark-v11',
					}
				),
			},
		],
	},
];

let overLayers = [
	{
		group: 'Instansi Pemerintah',
		layers: [
			{
				active: true,
				name: 'Dinas Kesehatan',
				layer: dinkes,
			},
			{
				active: true,
				name: 'Dinas Sosial',
				layer: dinsos,
			},
			{
				active: true,
				name: 'Dinas Kominfo',
				layer: diskominfo,
			},
		],
	},
];

let panelLayers = new L.Control.PanelLayers(baseLayers, overLayers);

myMap.addControl(panelLayers);
