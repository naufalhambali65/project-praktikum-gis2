<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Polygon</title>
  <!-- leaflet -->
  <link rel="stylesheet" href="assets/leaflet/leaflet.css">
  <script src="assets/leaflet/leaflet.js"></script>
  <!-- jquery -->
  <script src="assets/jquery/jquery-3.7.1.min.js"></script>
  <!-- leaflet draw -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw-src.css"
    integrity="sha512-vJfMKRRm4c4UupyPwGUZI8U651mSzbmmPgR3sdE3LcwBPsdGeARvUM5EcSTg34DK8YIRiIo+oJwNfZPMKEQyug=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"
    integrity="sha512-ozq8xQKq6urvuU6jNgkfqAmT7jKN2XumbrX1JiB3TnF7tI48DPI4Gy1GXKD/V3EExgAs1V+pRO7vwtS1LHg0Gw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <!-- bootstrap  -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
    integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous">
  </script>
</head>

</head>

<body>
  <div class="container">
    <div class="row m-2">
      <div class="col">
        <center>
          <h3>Modul 3 - Polygon</h3>
        </center>
      </div>
    </div>
    <div class="row m-2">
      <div class="col-md-12">
        <div id="map" class="border border-dark" style="height:550px;"></div>
      </div>
      <div class="col-md-12 m-3">
        <a href="tambah.php" class="btn btn-success">Tambah Data</a>
      </div>
      <div class="col-md-12">
        <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">No</th>
              <th scope="col">Nama</th>
              <th scope="col">Polygon</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 0;
            $query = $conn->query('SELECT * FROM polygon');
            while ($row = $query->fetch_assoc()) {
            ?>
            <tr>
              <td><?= $no += 1 ?></td>
              <td><?= $row['nama'] ?></td>
              <td><?= $row['polygon'] ?></td>
              <td>
                <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('data ingin dihapus?')"
                  class="btn btn-danger">Delete</a>
              </td>
            </tr>
            <?php
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
<script>
var map = L.map('map').setView([-0.8931699926701577, 119.86473745747928], 14);

let layerMap = L.tileLayer(
  'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibmF1ZmFsaGFtYmFsaTY1IiwiYSI6ImNtMnd4eWdlZDBidjYyanBwaHJnZ3FrbHAifQ.mJdw4Ew-5zOyObCXR8akhg', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
      '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
      'Imagery <a href="https://www.mapbox.com/">Mapbox</a>',
    id: 'mapbox/streets-v12',
  }
).addTo(map);
<?php
  $sql = "SELECT * FROM polygon";
  $hasil = $conn->query($sql);
  if ($hasil->num_rows > 0) {
    while ($row = $hasil->fetch_assoc()) { ?>
var drawnItems = L.geoJson(<?= $row['polygon'] ?>, {
  color: '<?= $row['warna'] ?>',
  opacity: 0.3,
  fillOpacity: 0.5,
}).bindPopup('Nama: <?= $row['nama'] ?>').addTo(map);
<?php
    }
  }
  ?>
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</html>