<?php
    $conn = new mysqli("localhost", "root", "", "gis-apotik");

    if (!$conn) {
        echo 'koneksi gagal';
    }
?>