<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Praktikum GIS</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- leaflet -->
  <link rel="stylesheet" href="assets/leaflet/leaflet.css">
  <script src="assets/leaflet/leaflet.js"></script>
  <!-- plugins Leaflet Panel Layers -->
  <link rel="stylesheet" href="assets/leaflet/leaflet-panel-layers-master/src/leaflet-panel-layers.css">
  <script src="assets/leaflet/leaflet-panel-layers-master/src/leaflet-panel-layers.js"></script>
</head>

<body>
  <h1>Praktikum GIS</h1>
  <div id="map">
  </div>
</body>
<script src="map.js"></script>

</html>