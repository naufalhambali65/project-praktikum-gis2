<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {

  $nama = $_POST['nama'];
  $latitude = $_POST['latitude'];
  $longitude = $_POST['longitude'];

  if ($nama == '') {
    echo "<script>alert('Masih ada data yang Kosong')</script>";
  } else {
    $sql = "INSERT INTO lokasi(nama, latitude, longitude) values ('" . $nama . "','" . $latitude . "','" . $longitude . "')";
    $hasil = $conn->query($sql);
    echo "<script>alert('Data berhasil ditambahkan')</script>";
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Praktikum GIS</title>
  <!-- css -->
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- leaflet -->
  <link rel="stylesheet" href="assets/leaflet/leaflet.css">
  <script src="assets/leaflet/leaflet.js"></script>
  <!-- jquery -->
  <script src="assets/jquery/jquery-3.7.1.min.js"></script>
</head>

<body>
  <h1>Tambah Lokasi</h1>
  <a href="index.php">
    <button>Lihat Lokasi</button>
  </a>

  <div class="container">
    <div id="mapinput"></div>
    <div class="form_input">
      <form action="" method="post" enctype="multipart/form">
        <table>
          <tr>
            <td>Nama Lokasi</td>
            <td>:</td>
            <td><input type="text" name="nama"></td>
          </tr>
          <tr>
            <td>Latitude</td>
            <td>:</td>
            <td><input type="text" name="latitude" id="latitude"></td>
          </tr>
          <tr>
            <td>Longitude</td>
            <td>:</td>
            <td><input type="text" name="longitude" id="longitude"></td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td><button type="submit" name="simpan">Simpan</button></td>
          </tr>
        </table>
      </form>
    </div>
    <hr>
    <br>
    <div class="data">
      <table border="1" cellspacing="0" cellpadding="5">
        <thead>
          <tr>
            <th>No.</th>
            <th>Nama</th>
            <th>Latitude</th>
            <th>Longitude</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 0;
          $sql = "SELECT * FROM lokasi ORDER BY id_lokasi ASC";
          $hasil = $conn->query($sql);
          if ($hasil->num_rows > 0) {
            while ($row = $hasil->fetch_row()) {
          ?>
          <tr>
            <td><?= $no += 1; ?></td>
            <td><?= $row[1] ?></td>
            <td><?= $row[2] ?></td>
            <td><?= $row[3] ?></td>
            <td>
              <a href="edit.php?id=<?= $row[0]; ?>">Edit</a> | <a href="delete.php?id=<?= $row[0]; ?>">Delete</a>
            </td>
          </tr>
          <?php
            }
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>

<script>
let latlang = [0, 0];
if (latlang[0] == 0 && latlang[1] == 0) {
  latlang = [-0.888027, 119.874693];
}

let myMap = L.map('mapinput').setView([-0.8931699926701577, 119.86473745747928], 14);
let layerMap = L.tileLayer(
  'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibmF1ZmFsaGFtYmFsaTY1IiwiYSI6ImNtMnd4eWdlZDBidjYyanBwaHJnZ3FrbHAifQ.mJdw4Ew-5zOyObCXR8akhg', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
      '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
      'Imagery <a href="https://www.mapbox.com/">Mapbox</a>',
    id: 'mapbox/streets-v12',
  });
myMap.addLayer(layerMap);
let marker = new L.marker(latlang, {
  draggable: 'true'
});
marker.on('dragend', function(event) {
  let position = marker.getLatLng();
  marker.setLatLng(position).update();
  $("#latitude").val(position.lat);
  $("#longitude").val(position.lng);
});
myMap.addLayer(marker);
</script>


</html>