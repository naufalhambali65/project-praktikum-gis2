<?php
include 'koneksi.php';
$id = $_GET['id'];
$queryResult = mysqli_query($conn, "DELETE FROM polygon WHERE id=$id");

if ($queryResult) {
  echo "<script>
  alert('data Berhasil dihapus');
  window.location.href='index.php';
  </script>";
}