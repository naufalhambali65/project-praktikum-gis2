<?php
$conn = mysqli_connect('localhost', 'root', '', 'praktikum_gis2_p2');

if (mysqli_connect_error()) {
  echo "Koneksi database gagal : " . mysqli_connect_error();
}
