<?php
include 'koneksi.php';
$id = $_GET['id'];
$sql = "DELETE FROM lokasi WHERE id_lokasi=$id";
$result = mysqli_query($conn, $sql);
header('Location: input_marker.php');