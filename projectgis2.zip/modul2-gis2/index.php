<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Praktikum GIS</title>
  <!-- css -->
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- leaflet -->
  <link rel="stylesheet" href="assets/leaflet/leaflet.css">
  <script src="assets/leaflet/leaflet.js"></script>
  <!-- jquery -->
  <script src="assets/jquery/jquery-3.7.1.min.js"></script>
</head>

<body>
  <h1>Praktikum 2 GIS 2 - Manipulasi Marker</h1>
  <a href="input_marker.php">
    <button>Tambah Lokasi</button>
  </a>
  <div id="map">
  </div>
</body>
<script>
var myMap = L.map('map').setView([-0.8931699926701577, 119.86473745747928], 14);

let layerMap = L.tileLayer(
  'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibmF1ZmFsaGFtYmFsaTY1IiwiYSI6ImNtMnd4eWdlZDBidjYyanBwaHJnZ3FrbHAifQ.mJdw4Ew-5zOyObCXR8akhg', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
      '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
      'Imagery <a href="https://www.mapbox.com/">Mapbox</a>',
    id: 'mapbox/streets-v12',
  }
);

myMap.addLayer(layerMap);

// Manipulasi Icon

let icon1 = L.icon({
  iconUrl: 'assets/icon/icon.svg',
  iconSize: [50, 50],
  iconAnchor: [25, 50],
  popupAnchor: [0, -50],
});

// Menampilkan lokasi 
<?php
  $sql = 'SELECT * FROM lokasi';
  $hasil = $conn->query($sql);
  if ($hasil->num_rows > 0) {
    while ($row = $hasil->fetch_row()) { ?>
L.marker([<?= $row[2] ?>, <?= $row[3] ?>], {
    icon: icon1
  })
  .bindPopup(`Nama : <?= $row[1] ?>`).addTo(myMap);
<?php
    }
  }
  ?>
</script>

</html>